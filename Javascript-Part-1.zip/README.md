# Javascript-Part-1
Javascript part 1
